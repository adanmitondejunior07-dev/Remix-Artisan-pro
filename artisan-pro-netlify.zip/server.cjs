var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path2 = __toESM(require("path"), 1);
var import_vite = require("vite");

// server/db.ts
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var DB_FILE = import_path.default.join(process.cwd(), "data", "artisan_pro_db.json");
var defaultPlans = [
  {
    name: "Free",
    price: "0 FCFA",
    priceNumber: 0,
    desc: "Pour commencer",
    features: [
      "Profil de base",
      "Pr\xE9sence dans la recherche",
      "Messagerie standard (max 5 contacts)",
      "1 service list\xE9"
    ]
  },
  {
    name: "Pro",
    price: "5 000 FCFA/mois",
    priceNumber: 5e3,
    desc: "Pour d\xE9velopper son activit\xE9",
    features: [
      "Tout le forfait Free",
      "Profil prioritaire dans les r\xE9sultats",
      "Statistiques de visites et contacts",
      "Jusqu\u2019\xE0 8 services list\xE9s",
      "Badge Pro v\xE9rifi\xE9",
      "Devis directs illimit\xE9s"
    ],
    featured: true
  },
  {
    name: "Premium",
    price: "10 000 FCFA/mois",
    priceNumber: 1e4,
    desc: "Pour maximiser sa visibilit\xE9",
    features: [
      "Tout le forfait Pro",
      "Mise en avant sur la page d\u2019accueil",
      "Priorit\xE9 absolue dans les r\xE9sultats g\xE9olocalis\xE9s",
      "Badge Premium dor\xE9",
      "Services illimit\xE9s dans la Marketplace",
      "Support commercial & assistance VIP"
    ]
  }
];
var defaultArtisans = [
  {
    id: 1,
    name: "Awa Kon\xE9",
    trade: "Couturi\xE8re",
    city: "Abidjan",
    country: "C\xF4te d\u2019Ivoire",
    rating: 4.9,
    reviewsCount: 48,
    plan: "Premium",
    emoji: "\u{1F457}",
    services: ["Robe sur mesure", "Tenue africaine", "Retouches"],
    description: "Atelier de haute couture africaine et moderne. Plus de 12 ans d\u2019exp\xE9rience dans la cr\xE9ation de robes de c\xE9r\xE9monie, boubous brod\xE9s et ensembles contemporains.",
    phone: "+225 07 45 67 89",
    email: "awa.kone@artisanpro.africa",
    lat: 5.3599,
    lng: -3.987,
    verified: true,
    hourlyRate: "15 000 FCFA",
    profileViews: 1420,
    contactsCount: 128,
    joinedDate: "2024-01-15",
    experienceYears: 12,
    address: "Cocody Cit\xE9 des Arts, Abidjan"
  },
  {
    id: 2,
    name: "Moussa Traor\xE9",
    trade: "\xC9lectricien",
    city: "Abidjan",
    country: "C\xF4te d\u2019Ivoire",
    rating: 4.8,
    reviewsCount: 39,
    plan: "Pro",
    emoji: "\u26A1",
    services: ["Installation", "D\xE9pannage", "Tableau \xE9lectrique"],
    description: "Artisan \xE9lectricien certifi\xE9 b\xE2timent et industrie. Interventions d\u2019urgence 24/7 pour pannes \xE9lectriques, conformit\xE9 et installations solaires.",
    phone: "+225 05 32 14 56",
    email: "moussa.traore@artisanpro.africa",
    lat: 5.3261,
    lng: -4.0197,
    verified: true,
    hourlyRate: "10 000 FCFA",
    profileViews: 980,
    contactsCount: 84,
    joinedDate: "2024-02-10",
    experienceYears: 8,
    address: "Plateau Rue du Commerce, Abidjan"
  },
  {
    id: 3,
    name: "Koffi Yao",
    trade: "M\xE9canicien",
    city: "Bouak\xE9",
    country: "C\xF4te d\u2019Ivoire",
    rating: 4.7,
    reviewsCount: 26,
    plan: "Pro",
    emoji: "\u{1F527}",
    services: ["Entretien", "Freins", "Diagnostic"],
    description: "Garage automobile toutes marques. Sp\xE9cialiste moteurs diesel et essence, vidanges, suspensions et diagnostics \xE9lectroniques complets.",
    phone: "+225 01 23 45 67",
    email: "koffi.yao@artisanpro.africa",
    lat: 7.6898,
    lng: -5.03,
    verified: true,
    hourlyRate: "12 000 FCFA",
    profileViews: 650,
    contactsCount: 52,
    joinedDate: "2024-03-01",
    experienceYears: 10,
    address: "Quartier Koko, Bouak\xE9"
  },
  {
    id: 4,
    name: "Fatou Diallo",
    trade: "Coiffeuse",
    city: "Dakar",
    country: "S\xE9n\xE9gal",
    rating: 4.9,
    reviewsCount: 62,
    plan: "Premium",
    emoji: "\u{1F487}\u{1F3FE}",
    services: ["Tresses", "Coiffure mariage", "Soins"],
    description: "Salon de beaut\xE9 & coiffure afro-carib\xE9enne. Passionn\xE9e par la valorisation du cheveu naturel, tissages, nattes et chignons de mari\xE9e.",
    phone: "+221 77 123 45 67",
    email: "fatou.diallo@artisanpro.africa",
    lat: 14.6928,
    lng: -17.4467,
    verified: true,
    hourlyRate: "8 000 FCFA",
    profileViews: 1850,
    contactsCount: 165,
    joinedDate: "2023-11-20",
    experienceYears: 7,
    address: "Almadies, Dakar"
  },
  {
    id: 5,
    name: "Jean N\u2019Guessan",
    trade: "Ma\xE7on",
    city: "Yamoussoukro",
    country: "C\xF4te d\u2019Ivoire",
    rating: 4.6,
    reviewsCount: 18,
    plan: "Free",
    emoji: "\u{1F9F1}",
    services: ["Construction", "R\xE9novation", "Carrelage"],
    description: "Ma\xE7onnerie g\xE9n\xE9rale, fondations solides, \xE9l\xE9vation de murs, cr\xE9pissage et pose de carrelage haut de gamme pour r\xE9sidences et commerces.",
    phone: "+225 07 88 99 00",
    email: "jean.nguessan@artisanpro.africa",
    lat: 6.8276,
    lng: -5.2893,
    verified: false,
    hourlyRate: "20 000 FCFA",
    profileViews: 426,
    contactsCount: 38,
    joinedDate: "2024-04-05",
    experienceYears: 14,
    address: "Quartier Habitat, Yamoussoukro"
  },
  {
    id: 6,
    name: "Ibrahim Coulibaly",
    trade: "Menuisier",
    city: "Abidjan",
    country: "C\xF4te d\u2019Ivoire",
    rating: 4.8,
    reviewsCount: 34,
    plan: "Pro",
    emoji: "\u{1FA9A}",
    services: ["Meubles", "Portes", "Cuisine"],
    description: "\xC9b\xE9nisterie et menuiserie bois massif et m\xE9lamin\xE9. Conception sur mesure de placards, dressings, meubles de salon et portes s\xE9curis\xE9es.",
    phone: "+225 05 98 76 54",
    email: "ibrahim.coulibaly@artisanpro.africa",
    lat: 5.34,
    lng: -4.08,
    verified: true,
    hourlyRate: "18 000 FCFA",
    profileViews: 820,
    contactsCount: 71,
    joinedDate: "2024-02-18",
    experienceYears: 9,
    address: "Yopougon Niangon Sud, Abidjan"
  },
  {
    id: 7,
    name: "S\xE8gla Dossou",
    trade: "Plombier",
    city: "Cotonou",
    country: "B\xE9nin",
    rating: 4.9,
    reviewsCount: 31,
    plan: "Pro",
    emoji: "\u{1F6BF}",
    services: ["Installation sanitaire", "D\xE9bouchage express", "Chauffe-eau solaire"],
    description: "Plombier sanitaire qualifi\xE9 disponible sur Cotonou et Calavi. D\xE9pannages d\u2019urgence, fuites d\u2019eau et r\xE9novation de salles de bain.",
    phone: "+229 97 11 22 33",
    email: "segla.dossou@artisanpro.africa",
    lat: 6.3703,
    lng: 2.3912,
    verified: true,
    hourlyRate: "8 000 FCFA",
    profileViews: 710,
    contactsCount: 64,
    joinedDate: "2024-03-12",
    experienceYears: 8,
    address: "Haie Vive, Cotonou"
  },
  {
    id: 8,
    name: "Samuel Ebanda",
    trade: "\xC9lectricien",
    city: "Douala",
    country: "Cameroun",
    rating: 4.8,
    reviewsCount: 45,
    plan: "Premium",
    emoji: "\u26A1",
    services: ["R\xE9seaux domestiques", "Groupes \xE9lectrog\xE8nes", "Climatisation"],
    description: "Expert en installations \xE9lectriques et maintenance de climatiseurs \xE0 Douala et Yaound\xE9. Respect strict des normes de s\xE9curit\xE9.",
    phone: "+237 690 12 34 56",
    email: "samuel.ebanda@artisanpro.africa",
    lat: 4.0511,
    lng: 9.7679,
    verified: true,
    hourlyRate: "12 000 FCFA",
    profileViews: 1140,
    contactsCount: 92,
    joinedDate: "2024-01-20",
    experienceYears: 11,
    address: "Akwa, Douala"
  },
  {
    id: 9,
    name: "Komi Agbessi",
    trade: "Soudeur",
    city: "Lom\xE9",
    country: "Togo",
    rating: 4.7,
    reviewsCount: 22,
    plan: "Pro",
    emoji: "\u{1F468}\u200D\u{1F3ED}",
    services: ["Grilles de s\xE9curit\xE9", "Portails m\xE9talliques", "Charpentes en fer"],
    description: "Ferronnerie d\u2019art et soudure m\xE9tallique de haute r\xE9sistance pour r\xE9sidences, villas et hangars industriels \xE0 Lom\xE9.",
    phone: "+228 90 12 34 56",
    email: "komi.agbessi@artisanpro.africa",
    lat: 6.1375,
    lng: 1.2123,
    verified: true,
    hourlyRate: "7 500 FCFA",
    profileViews: 530,
    contactsCount: 44,
    joinedDate: "2024-04-01",
    experienceYears: 7,
    address: "Hedzranawo\xE9, Lom\xE9"
  },
  {
    id: 10,
    name: "Ousmane Traor\xE9",
    trade: "Menuisier",
    city: "Bamako",
    country: "Mali",
    rating: 4.9,
    reviewsCount: 29,
    plan: "Pro",
    emoji: "\u{1FA9A}",
    services: ["Salons traditionnels", "Chambres \xE0 coucher", "Portes massives"],
    description: "Ma\xEEtre artisan menuisier sur bois de teck et bois pr\xE9cieux. Finitions soign\xE9es et livraison ponctuelle partout \xE0 Bamako.",
    phone: "+223 76 54 32 10",
    email: "ousmane.traore@artisanpro.africa",
    lat: 12.6392,
    lng: -8.0029,
    verified: true,
    hourlyRate: "10 000 FCFA",
    profileViews: 680,
    contactsCount: 58,
    joinedDate: "2024-02-28",
    experienceYears: 13,
    address: "Badalabougou, Bamako"
  },
  {
    id: 11,
    name: "Dieudonn\xE9 Mukendi",
    trade: "Peintre",
    city: "Kinshasa",
    country: "RD Congo",
    rating: 4.8,
    reviewsCount: 38,
    plan: "Premium",
    emoji: "\u{1F3A8}",
    services: ["Peinture d\xE9corative", "Rev\xEAtements \xE9tanches", "Fresques modernes"],
    description: "Entreprise de peinture et d\xE9coration int\xE9rieure/ext\xE9rieure \xE0 Kinshasa (Gombe, Kintambo, Limete). Travail rapide et propre.",
    phone: "+243 81 234 5678",
    email: "dieudonne.mukendi@artisanpro.africa",
    lat: -4.3276,
    lng: 15.3136,
    verified: true,
    hourlyRate: "15 $ / h",
    profileViews: 890,
    contactsCount: 76,
    joinedDate: "2024-01-10",
    experienceYears: 10,
    address: "Gombe, Kinshasa"
  }
];
var defaultUsers = [
  {
    id: "user-client-1",
    name: "Aminata Tour\xE9",
    email: "aminata.toure@gmail.com",
    role: "client",
    phone: "+225 07 12 34 56",
    city: "Abidjan",
    country: "C\xF4te d\u2019Ivoire",
    avatar: "\u{1F469}\u{1F3FD}"
  },
  {
    id: "user-artisan-1",
    name: "Awa Kon\xE9",
    email: "awa.kone@artisanpro.africa",
    role: "artisan",
    phone: "+225 07 45 67 89",
    city: "Abidjan",
    country: "C\xF4te d\u2019Ivoire",
    artisanId: 1,
    avatar: "\u{1F457}"
  },
  {
    id: "user-artisan-2",
    name: "Moussa Traor\xE9",
    email: "moussa.traore@artisanpro.africa",
    role: "artisan",
    phone: "+225 05 32 14 56",
    city: "Abidjan",
    country: "C\xF4te d\u2019Ivoire",
    artisanId: 2,
    avatar: "\u26A1"
  },
  {
    id: "user-admin-principal",
    name: "Admin Principal ArtisanPro Africa",
    email: "contactartisanproafrica@gmail.com",
    role: "super_admin",
    phone: "+225 0503444508",
    city: "Abidjan",
    country: "C\xF4te d\u2019Ivoire",
    avatar: "\u{1F6E1}\uFE0F"
  },
  {
    id: "user-admin-adan",
    name: "Adan Mitonde (Admin Secondaire)",
    email: "adanmitondejunior07@gmail.com",
    role: "super_admin",
    phone: "+225 0503444508",
    city: "Abidjan",
    country: "C\xF4te d\u2019Ivoire",
    avatar: "\u{1F6E1}\uFE0F"
  }
];
var defaultServices = [
  {
    id: "srv-1",
    artisanId: 1,
    artisanName: "Awa Kon\xE9",
    trade: "Couturi\xE8re",
    title: "Robe de soir\xE9e sur mesure",
    price: "25 000 FCFA",
    priceValue: 25e3,
    city: "Abidjan",
    country: "C\xF4te d\u2019Ivoire",
    description: "Prise de mesures \xE0 domicile ou \xE0 l\u2019atelier, s\xE9lection du tissu et confection soign\xE9e sous 5 jours ouvr\xE9s.",
    category: "Couture",
    duration: "4-6 jours",
    emoji: "\u{1F457}"
  },
  {
    id: "srv-2",
    artisanId: 1,
    artisanName: "Awa Kon\xE9",
    trade: "Couturi\xE8re",
    title: "Ensemble traditionnel en Pagne Baoul\xE9",
    price: "35 000 FCFA",
    priceValue: 35e3,
    city: "Abidjan",
    country: "C\xF4te d\u2019Ivoire",
    description: "Broderie artisanale fine, doublure satin\xE9e et finitions soign\xE9es pour vos mariages et c\xE9r\xE9monies.",
    category: "Couture",
    duration: "7 jours",
    emoji: "\u{1F9F5}"
  },
  {
    id: "srv-3",
    artisanId: 2,
    artisanName: "Moussa Traor\xE9",
    trade: "\xC9lectricien",
    title: "Diagnostic & R\xE9novation de tableau \xE9lectrique",
    price: "30 000 FCFA",
    priceValue: 3e4,
    city: "Abidjan",
    country: "C\xF4te d\u2019Ivoire",
    description: "Mise aux normes NF C 15-100, remplacement de disjoncteurs diff\xE9rentiels et test de mise \xE0 la terre.",
    category: "\xC9lectricit\xE9",
    duration: "1 journ\xE9e",
    emoji: "\u26A1"
  },
  {
    id: "srv-4",
    artisanId: 2,
    artisanName: "Moussa Traor\xE9",
    trade: "\xC9lectricien",
    title: "Installation d\u2019inverseur automatique groupe/secteur",
    price: "45 000 FCFA",
    priceValue: 45e3,
    city: "Abidjan",
    country: "C\xF4te d\u2019Ivoire",
    description: "Automatisation du basculement entre la CIE et votre groupe \xE9lectrog\xE8ne sans coupure brutale.",
    category: "\xC9lectricit\xE9",
    duration: "1/2 journ\xE9e",
    emoji: "\u{1F50C}"
  },
  {
    id: "srv-5",
    artisanId: 3,
    artisanName: "Koffi Yao",
    trade: "M\xE9canicien",
    title: "Vidange int\xE9grale & R\xE9vision 30 points",
    price: "20 000 FCFA",
    priceValue: 2e4,
    city: "Bouak\xE9",
    country: "C\xF4te d\u2019Ivoire",
    description: "Changement huile 100% synth\xE8se, filtres \xE0 huile/air/carburant et contr\xF4le complet des organes de s\xE9curit\xE9.",
    category: "M\xE9canique",
    duration: "2 heures",
    emoji: "\u{1F527}"
  },
  {
    id: "srv-6",
    artisanId: 4,
    artisanName: "Fatou Diallo",
    trade: "Coiffeuse",
    title: "Tresses s\xE9n\xE9galaises (Twists / Knotless Braids)",
    price: "15 000 FCFA",
    priceValue: 15e3,
    city: "Dakar",
    country: "S\xE9n\xE9gal",
    description: "Tressage soign\xE9 sans douleur sur les racines, tenue garantie 6 semaines avec soins nourrissants offerts.",
    category: "Coiffure",
    duration: "3-4 heures",
    emoji: "\u{1F487}\u{1F3FE}"
  },
  {
    id: "srv-7",
    artisanId: 5,
    artisanName: "Jean N\u2019Guessan",
    trade: "Ma\xE7on",
    title: "Pose de carrelage int\xE9rieur 60x60",
    price: "3 500 FCFA / m\xB2",
    priceValue: 3500,
    city: "Yamoussoukro",
    country: "C\xF4te d\u2019Ivoire",
    description: "Chape de nivellement, colle haute adh\xE9rence et joints hydrofuges impeccables.",
    category: "Ma\xE7onnerie",
    duration: "2-3 jours",
    emoji: "\u{1F9F1}"
  },
  {
    id: "srv-8",
    artisanId: 6,
    artisanName: "Ibrahim Coulibaly",
    trade: "Menuisier",
    title: "Conception & Pose de placard dressing en bois",
    price: "85 000 FCFA",
    priceValue: 85e3,
    city: "Abidjan",
    country: "C\xF4te d\u2019Ivoire",
    description: "Dressing moderne 3 battants avec tiroirs \xE0 amortisseurs, \xE9tag\xE8res r\xE9glables et penderie robuste.",
    category: "Menuiserie",
    duration: "5 jours",
    emoji: "\u{1FA9A}"
  }
];
var defaultMessages = [
  {
    id: "msg-1",
    conversationId: "conv-1-user-client-1",
    senderId: "user-client-1",
    senderName: "Aminata Tour\xE9",
    senderRole: "client",
    artisanId: 1,
    clientId: "user-client-1",
    text: "Bonjour Madame Kon\xE9, faites-vous des retouches rapides pour un mariage pr\xE9vu samedi ?",
    timestamp: "2026-09-06T10:30:00Z"
  },
  {
    id: "msg-2",
    conversationId: "conv-1-user-client-1",
    senderId: "user-artisan-1",
    senderName: "Awa Kon\xE9",
    senderRole: "artisan",
    artisanId: 1,
    clientId: "user-client-1",
    text: "Bonjour Aminata ! Oui tout \xE0 fait, vous pouvez passer \xE0 l\u2019atelier \xE0 Cocody cet apr\xE8s-midi pour les mesures.",
    timestamp: "2026-09-06T10:45:00Z"
  },
  {
    id: "msg-3",
    conversationId: "conv-2-user-client-1",
    senderId: "user-client-1",
    senderName: "Aminata Tour\xE9",
    senderRole: "client",
    artisanId: 2,
    clientId: "user-client-1",
    text: "Bonjour Moussa, mon disjoncteur saute d\xE8s que j\u2019allume le climatiseur.",
    timestamp: "2026-09-05T14:10:00Z"
  },
  {
    id: "msg-4",
    conversationId: "conv-2-user-client-1",
    senderId: "user-artisan-2",
    senderName: "Moussa Traor\xE9",
    senderRole: "artisan",
    artisanId: 2,
    clientId: "user-client-1",
    text: "Bonjour ! C\u2019est probablement une surcharge ou un court-circuit au compresseur. Je peux intervenir demain \xE0 9h.",
    timestamp: "2026-09-05T14:25:00Z"
  }
];
var defaultQuotes = [
  {
    id: "quote-101",
    clientId: "user-client-1",
    clientName: "Aminata Tour\xE9",
    clientPhone: "+225 07 12 34 56",
    artisanId: 1,
    artisanName: "Awa Kon\xE9",
    serviceTitle: "Robe de mari\xE9e traditionnelle Baoul\xE9",
    description: "Confection compl\xE8te avec tissu fourni, taille 38, finitions perles dor\xE9es pour le 25 septembre.",
    status: "en_attente",
    estimatedPrice: "45 000 FCFA",
    date: "2026-09-06T11:00:00Z"
  },
  {
    id: "quote-102",
    clientId: "user-client-1",
    clientName: "Aminata Tour\xE9",
    clientPhone: "+225 07 12 34 56",
    artisanId: 2,
    artisanName: "Moussa Traor\xE9",
    serviceTitle: "Installation tableau \xE9lectrique duplex",
    description: "C\xE2blage neuf 8 d\xE9parts + parafoudre + disjoncteur diff\xE9rentiel.",
    status: "accepte",
    estimatedPrice: "65 000 FCFA",
    date: "2026-09-04T09:20:00Z"
  }
];
var defaultTransactions = [
  {
    id: "tx-2024-001",
    artisanId: 1,
    artisanName: "Awa Kon\xE9",
    plan: "Premium",
    amount: 1e4,
    currency: "FCFA",
    method: "Wave",
    status: "reussi",
    date: "2026-09-01T08:15:00Z",
    invoiceNumber: "INV-2026-09-001"
  },
  {
    id: "tx-2024-002",
    artisanId: 2,
    artisanName: "Moussa Traor\xE9",
    plan: "Pro",
    amount: 5e3,
    currency: "FCFA",
    method: "Orange Money",
    status: "reussi",
    date: "2026-09-02T14:40:00Z",
    invoiceNumber: "INV-2026-09-002"
  },
  {
    id: "tx-2024-003",
    artisanId: 4,
    artisanName: "Fatou Diallo",
    plan: "Premium",
    amount: 1e4,
    currency: "FCFA",
    method: "Wave",
    status: "reussi",
    date: "2026-09-03T11:20:00Z",
    invoiceNumber: "INV-2026-09-003"
  },
  {
    id: "tx-2024-004",
    artisanId: 6,
    artisanName: "Ibrahim Coulibaly",
    plan: "Pro",
    amount: 5e3,
    currency: "FCFA",
    method: "MTN MoMo",
    status: "reussi",
    date: "2026-09-04T16:05:00Z",
    invoiceNumber: "INV-2026-09-004"
  }
];
var defaultNotifications = [
  {
    id: "notif-1",
    recipientId: "all",
    title: "Bienvenue sur Artisan Pro !",
    message: "D\xE9couvrez les artisans v\xE9rifi\xE9s pr\xE8s de chez vous ou boostez votre activit\xE9 artisanale.",
    type: "system",
    date: "2026-09-01T08:00:00Z",
    read: false,
    linkPage: "home"
  },
  {
    id: "notif-2",
    recipientId: "user-client-1",
    title: "Devis accept\xE9 par Moussa Traor\xE9",
    message: "Votre demande d\u2019installation de tableau \xE9lectrique a \xE9t\xE9 valid\xE9e pour 65 000 FCFA.",
    type: "quote",
    date: "2026-09-04T10:00:00Z",
    read: false,
    linkPage: "messages"
  },
  {
    id: "notif-3",
    recipientId: "user-artisan-1",
    title: "Abonnement Premium actif !",
    message: "Votre compte b\xE9n\xE9ficie de la visibilit\xE9 maximale et du badge Premium dor\xE9.",
    type: "payment",
    date: "2026-09-01T08:16:00Z",
    read: true,
    linkPage: "subscription"
  }
];
var DatabaseStore = class {
  constructor() {
    this.data = this.loadData();
  }
  loadData() {
    try {
      if (import_fs.default.existsSync(DB_FILE)) {
        const raw = import_fs.default.readFileSync(DB_FILE, "utf-8");
        const parsed = JSON.parse(raw);
        const existingArtisans = parsed.artisans || [];
        defaultArtisans.forEach((def) => {
          if (!existingArtisans.some((a) => a.id === def.id)) {
            existingArtisans.push(def);
          }
        });
        return {
          artisans: existingArtisans.length ? existingArtisans : defaultArtisans,
          plans: parsed.plans || defaultPlans,
          users: parsed.users || defaultUsers,
          services: parsed.services || defaultServices,
          messages: parsed.messages || defaultMessages,
          quotes: parsed.quotes || defaultQuotes,
          transactions: parsed.transactions || defaultTransactions,
          notifications: parsed.notifications || defaultNotifications,
          subscriptions: parsed.subscriptions || [],
          payments: parsed.payments || []
        };
      }
    } catch (err) {
      console.warn("Failed to read db file, initializing with defaults:", err);
    }
    const initial = {
      artisans: defaultArtisans,
      plans: defaultPlans,
      users: defaultUsers,
      services: defaultServices,
      messages: defaultMessages,
      quotes: defaultQuotes,
      transactions: defaultTransactions,
      notifications: defaultNotifications,
      subscriptions: [],
      payments: []
    };
    this.saveData(initial);
    return initial;
  }
  saveData(data) {
    try {
      const dir = import_path.default.dirname(DB_FILE);
      if (!import_fs.default.existsSync(dir)) {
        import_fs.default.mkdirSync(dir, { recursive: true });
      }
      import_fs.default.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf-8");
    } catch (err) {
      console.error("Failed to write database file:", err);
    }
  }
  persist() {
    this.saveData(this.data);
  }
  // Artisans
  getArtisans() {
    return this.data.artisans;
  }
  getArtisanById(id) {
    return this.data.artisans.find((a) => a.id === id);
  }
  createArtisan(payload) {
    const maxId = this.data.artisans.reduce((max, a) => Math.max(max, a.id), 0);
    const newArtisan = {
      ...payload,
      id: maxId + 1
    };
    this.data.artisans.push(newArtisan);
    this.persist();
    return newArtisan;
  }
  updateArtisan(id, updates) {
    const idx = this.data.artisans.findIndex((a) => a.id === id);
    if (idx === -1) return null;
    this.data.artisans[idx] = { ...this.data.artisans[idx], ...updates };
    this.persist();
    return this.data.artisans[idx];
  }
  deleteArtisan(id) {
    const initialLen = this.data.artisans.length;
    this.data.artisans = this.data.artisans.filter((a) => a.id !== id);
    if (this.data.artisans.length !== initialLen) {
      this.persist();
      return true;
    }
    return false;
  }
  // Plans
  getPlans() {
    return this.data.plans;
  }
  // Users & Auth
  getUsers() {
    return this.data.users;
  }
  getUserById(id) {
    return this.data.users.find((u) => u.id === id);
  }
  getUserByEmail(email) {
    return this.data.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  }
  createUser(user) {
    this.data.users.push(user);
    this.persist();
    return user;
  }
  updateUser(id, updates) {
    const idx = this.data.users.findIndex((u) => u.id === id || String(u.id) === String(id));
    if (idx === -1) return null;
    this.data.users[idx] = { ...this.data.users[idx], ...updates };
    this.persist();
    return this.data.users[idx];
  }
  // Services
  getServices() {
    return this.data.services;
  }
  createService(service) {
    this.data.services.push(service);
    this.persist();
    return service;
  }
  // Messages
  getMessages(artisanId, clientId) {
    if (artisanId && clientId) {
      return this.data.messages.filter(
        (m) => m.artisanId === artisanId && m.clientId === clientId
      );
    }
    if (artisanId) {
      return this.data.messages.filter((m) => m.artisanId === artisanId);
    }
    if (clientId) {
      return this.data.messages.filter((m) => m.clientId === clientId);
    }
    return this.data.messages;
  }
  createMessage(msg) {
    this.data.messages.push(msg);
    this.persist();
    return msg;
  }
  // Quotes
  getQuotes(filter) {
    return this.data.quotes.filter((q) => {
      if (filter?.clientId && q.clientId !== filter.clientId) return false;
      if (filter?.artisanId && q.artisanId !== filter.artisanId) return false;
      return true;
    });
  }
  createQuote(quote) {
    this.data.quotes.push(quote);
    this.persist();
    return quote;
  }
  updateQuoteStatus(id, status) {
    const quote = this.data.quotes.find((q) => q.id === id);
    if (!quote) return null;
    quote.status = status;
    this.persist();
    return quote;
  }
  // Transactions
  getTransactions() {
    return this.data.transactions;
  }
  createTransaction(tx) {
    this.data.transactions.unshift(tx);
    this.persist();
    return tx;
  }
  // Notifications
  getNotifications(userId) {
    return this.data.notifications.filter(
      (n) => n.recipientId === "all" || userId && n.recipientId === userId
    );
  }
  createNotification(notif) {
    this.data.notifications.unshift(notif);
    this.persist();
    return notif;
  }
  markNotificationRead(id) {
    const notif = this.data.notifications.find((n) => n.id === id);
    if (notif) {
      notif.read = true;
      this.persist();
      return true;
    }
    return false;
  }
  markAllNotificationsRead(userId) {
    this.data.notifications.forEach((n) => {
      if (n.recipientId === "all" || userId && n.recipientId === userId) {
        n.read = true;
      }
    });
    this.persist();
  }
  // Admin summary
  getAdminStats() {
    const totalArtisans = this.data.artisans.length;
    const proCount = this.data.artisans.filter((a) => a.plan === "Pro").length;
    const premiumCount = this.data.artisans.filter((a) => a.plan === "Premium").length;
    const freeCount = this.data.artisans.filter((a) => a.plan === "Free").length;
    const pendingVerifications = this.data.artisans.filter((a) => !a.verified).length;
    const totalMonthlyRevenueFCFA = proCount * 5e3 + premiumCount * 1e4 + 234e4;
    return {
      totalArtisans,
      proCount,
      premiumCount,
      freeCount,
      totalMonthlyRevenueFCFA,
      pendingVerifications,
      totalQuotes: this.data.quotes.length,
      totalMessages: this.data.messages.length
    };
  }
  // ==========================================
  // TABLE: Subscriptions
  // ==========================================
  getSubscriptions() {
    return [...this.data.subscriptions || []];
  }
  getSubscriptionById(id) {
    return (this.data.subscriptions || []).find((s) => s.id === id);
  }
  getUserSubscriptions(userId) {
    return (this.data.subscriptions || []).filter((s) => s.user_id === userId);
  }
  createSubscription(sub) {
    if (!this.data.subscriptions) {
      this.data.subscriptions = [];
    }
    this.data.subscriptions.push(sub);
    this.persist();
    return sub;
  }
  updateSubscription(id, updates) {
    if (!this.data.subscriptions) return null;
    const index = this.data.subscriptions.findIndex((s) => s.id === id);
    if (index === -1) return null;
    this.data.subscriptions[index] = { ...this.data.subscriptions[index], ...updates };
    this.persist();
    return this.data.subscriptions[index];
  }
  // ==========================================
  // TABLE: Payments
  // ==========================================
  getPayments() {
    return [...this.data.payments || []];
  }
  getPaymentById(id) {
    return (this.data.payments || []).find((p) => p.id === id);
  }
  getUserPayments(userId) {
    return (this.data.payments || []).filter((p) => p.user_id === userId);
  }
  createPayment(payment) {
    if (!this.data.payments) {
      this.data.payments = [];
    }
    this.data.payments.push(payment);
    this.persist();
    return payment;
  }
  updatePayment(id, updates) {
    if (!this.data.payments) return null;
    const index = this.data.payments.findIndex((p) => p.id === id);
    if (index === -1) return null;
    this.data.payments[index] = { ...this.data.payments[index], ...updates };
    this.persist();
    return this.data.payments[index];
  }
};
var db = new DatabaseStore();

// server.ts
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json());
  app.use(import_express.default.urlencoded({ extended: true }));
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: (/* @__PURE__ */ new Date()).toISOString() });
  });
  app.get(["/artisan-pro-netlify.zip", "/api/download-netlify-zip"], (req, res) => {
    const zipPath = import_path2.default.join(process.cwd(), "public", "artisan-pro-netlify.zip");
    res.download(zipPath, "artisan-pro-netlify.zip");
  });
  app.get("/api/artisans", (req, res) => {
    const q = (req.query.q || "").toLowerCase().trim();
    const trade = (req.query.trade || "").toLowerCase().trim();
    const city = (req.query.city || "").toLowerCase().trim();
    const plan = (req.query.plan || "").toLowerCase().trim();
    let artisans = db.getArtisans();
    if (q) {
      artisans = artisans.filter((a) => {
        const full = `${a.name} ${a.trade} ${a.city} ${a.country} ${a.services.join(" ")} ${a.description}`.toLowerCase();
        return full.includes(q);
      });
    }
    if (trade) {
      artisans = artisans.filter((a) => a.trade.toLowerCase().includes(trade));
    }
    if (city) {
      artisans = artisans.filter((a) => a.city.toLowerCase().includes(city));
    }
    if (plan) {
      artisans = artisans.filter((a) => a.plan.toLowerCase() === plan);
    }
    artisans.sort((a, b) => {
      const planWeight = { Premium: 3, Pro: 2, Free: 1 };
      const diff = planWeight[b.plan] - planWeight[a.plan];
      if (diff !== 0) return diff;
      return b.rating - a.rating;
    });
    res.json(artisans);
  });
  app.get("/api/artisans/:id", (req, res) => {
    const id = parseInt(req.params.id, 10);
    const artisan = db.getArtisanById(id);
    if (!artisan) {
      return res.status(404).json({ error: "Artisan non trouv\xE9" });
    }
    db.updateArtisan(id, { profileViews: (artisan.profileViews || 0) + 1 });
    res.json(artisan);
  });
  app.post("/api/artisans", (req, res) => {
    const body = req.body;
    if (!body.name || !body.trade || !body.city) {
      return res.status(400).json({ error: "Champs obligatoires manquants: nom, m\xE9tier, ville" });
    }
    const emojiTradeMap = {
      couturier: "\u{1F457}",
      couturi\u00E8re: "\u{1F457}",
      \u00E9lectricien: "\u26A1",
      electricien: "\u26A1",
      m\u00E9canicien: "\u{1F527}",
      mecanicien: "\u{1F527}",
      coiffeur: "\u{1F487}\u{1F3FE}",
      coiffeuse: "\u{1F487}\u{1F3FE}",
      ma\u00E7on: "\u{1F9F1}",
      macon: "\u{1F9F1}",
      menuisier: "\u{1FA9A}",
      plombier: "\u{1F6BF}",
      peintre: "\u{1F3A8}",
      soudeur: "\u{1F468}\u200D\u{1F3ED}"
    };
    const lowerTrade = body.trade.toLowerCase();
    let detectedEmoji = "\u{1F6E0}\uFE0F";
    for (const [key, val] of Object.entries(emojiTradeMap)) {
      if (lowerTrade.includes(key)) {
        detectedEmoji = val;
        break;
      }
    }
    const newArtisan = db.createArtisan({
      name: body.name,
      trade: body.trade,
      city: body.city,
      country: body.country || "C\xF4te d\u2019Ivoire",
      rating: 5,
      reviewsCount: 1,
      plan: body.plan || "Free",
      emoji: body.emoji || detectedEmoji,
      services: Array.isArray(body.services) && body.services.length > 0 ? body.services : ["Prestation sur devis"],
      description: body.description || `Artisan professionnel sp\xE9cialis\xE9 en ${body.trade} \xE0 ${body.city}. Travail soign\xE9 et devis rapide.`,
      phone: body.phone || "+225 00 00 00 00",
      email: body.email || `${body.name.toLowerCase().replace(/\s+/g, ".")}@artisanpro.africa`,
      lat: body.lat || 5.3484,
      lng: body.lng || -4.018,
      verified: false,
      hourlyRate: body.hourlyRate || "10 000 FCFA",
      profileViews: 1,
      contactsCount: 0,
      joinedDate: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      experienceYears: body.experienceYears || 5,
      address: body.address || `${body.city}, ${body.country || "C\xF4te d\u2019Ivoire"}`
    });
    db.createUser({
      id: `user-artisan-${newArtisan.id}`,
      name: newArtisan.name,
      email: newArtisan.email,
      role: "artisan",
      phone: newArtisan.phone,
      city: newArtisan.city,
      country: newArtisan.country,
      artisanId: newArtisan.id,
      avatar: newArtisan.emoji
    });
    db.createNotification({
      id: `notif-${Date.now()}`,
      recipientId: "user-admin-1",
      title: "Nouvelle inscription artisan",
      message: `${newArtisan.name} (${newArtisan.trade} - ${newArtisan.city}) vient de cr\xE9er son profil. En attente de v\xE9rification.`,
      type: "system",
      date: (/* @__PURE__ */ new Date()).toISOString(),
      read: false,
      linkPage: "admin"
    });
    res.status(201).json(newArtisan);
  });
  app.put("/api/artisans/:id", (req, res) => {
    const id = parseInt(req.params.id, 10);
    const updated = db.updateArtisan(id, req.body);
    if (!updated) {
      return res.status(404).json({ error: "Artisan non trouv\xE9" });
    }
    res.json(updated);
  });
  app.delete("/api/artisans/:id", (req, res) => {
    const id = parseInt(req.params.id, 10);
    const deleted = db.deleteArtisan(id);
    if (!deleted) {
      return res.status(404).json({ error: "Artisan non trouv\xE9" });
    }
    res.json({ success: true });
  });
  app.get("/api/plans", (req, res) => {
    res.json(db.getPlans());
  });
  app.get("/api/auth/users", (req, res) => {
    res.json(db.getUsers());
  });
  app.post("/api/auth/login", (req, res) => {
    const { email, role, userId } = req.body;
    let user;
    if (userId) {
      user = db.getUserById(userId);
    } else if (email) {
      user = db.getUserByEmail(email);
    } else if (role) {
      user = db.getUsers().find((u) => u.role === role);
    }
    if (!user) {
      return res.status(401).json({ error: "Identifiants invalides ou utilisateur introuvable." });
    }
    let artisanData;
    if (user.artisanId) {
      artisanData = db.getArtisanById(user.artisanId);
    }
    res.json({ user, artisan: artisanData });
  });
  app.post("/api/auth/register", (req, res) => {
    const { name, email, role, phone, city, country, trade, description } = req.body;
    if (!name || !email) {
      return res.status(400).json({ error: "Nom et adresse email requis" });
    }
    const existing = db.getUserByEmail(email);
    if (existing) {
      return res.status(400).json({ error: "Un compte avec cet email existe d\xE9j\xE0" });
    }
    let artisanId;
    let createdArtisan;
    if (role === "artisan" && trade) {
      createdArtisan = db.createArtisan({
        name,
        trade,
        city: city || "Abidjan",
        country: country || "C\xF4te d\u2019Ivoire",
        rating: 5,
        reviewsCount: 1,
        plan: "Free",
        emoji: "\u{1F6E0}\uFE0F",
        services: ["Prestation sur devis"],
        description: description || `Artisan ${trade} qualifi\xE9 et disponible.`,
        phone: phone || "+225 00 00 00 00",
        email,
        lat: 5.35,
        lng: -4.01,
        verified: false,
        hourlyRate: "10 000 FCFA",
        profileViews: 1,
        contactsCount: 0,
        joinedDate: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
      });
      artisanId = createdArtisan.id;
    }
    const newUser = {
      id: `user-${Date.now()}`,
      name,
      email,
      role: role || "client",
      phone: phone || "+225 00 00 00 00",
      city: city || "Abidjan",
      country: country || "C\xF4te d\u2019Ivoire",
      artisanId,
      avatar: role === "artisan" ? "\u{1F6E0}\uFE0F" : "\u{1F464}"
    };
    db.createUser(newUser);
    res.status(201).json({ user: newUser, artisan: createdArtisan });
  });
  app.get("/api/services", (req, res) => {
    const q = (req.query.q || "").toLowerCase().trim();
    const category = (req.query.category || "").toLowerCase().trim();
    const city = (req.query.city || "").toLowerCase().trim();
    let services = db.getServices();
    if (q) {
      services = services.filter((s) => {
        const full = `${s.title} ${s.description} ${s.artisanName} ${s.trade} ${s.city}`.toLowerCase();
        return full.includes(q);
      });
    }
    if (category && category !== "tous") {
      services = services.filter((s) => s.category.toLowerCase() === category);
    }
    if (city && city !== "toutes") {
      services = services.filter((s) => s.city.toLowerCase().includes(city));
    }
    res.json(services);
  });
  app.post("/api/services", (req, res) => {
    const body = req.body;
    const service = {
      id: `srv-${Date.now()}`,
      artisanId: body.artisanId,
      artisanName: body.artisanName,
      trade: body.trade,
      title: body.title,
      price: body.price,
      priceValue: body.priceValue || 15e3,
      city: body.city,
      country: body.country || "C\xF4te d\u2019Ivoire",
      description: body.description,
      category: body.category || "G\xE9n\xE9ral",
      duration: body.duration || "24-48h",
      emoji: body.emoji || "\u2728"
    };
    db.createService(service);
    res.status(201).json(service);
  });
  app.get("/api/messages", (req, res) => {
    const artisanId = req.query.artisanId ? parseInt(req.query.artisanId, 10) : void 0;
    const clientId = req.query.clientId;
    const msgs = db.getMessages(artisanId, clientId);
    res.json(msgs);
  });
  app.post("/api/messages", (req, res) => {
    const { artisanId, clientId, text, senderId, senderName, senderRole } = req.body;
    if (!text || !text.trim()) {
      return res.status(400).json({ error: "Message vide" });
    }
    const newMsg = {
      id: `msg-${Date.now()}`,
      conversationId: `conv-${artisanId}-${clientId}`,
      senderId: senderId || clientId || "user-client-1",
      senderName: senderName || "Client",
      senderRole: senderRole || "client",
      artisanId: parseInt(artisanId, 10),
      clientId: clientId || "user-client-1",
      text: text.trim(),
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.createMessage(newMsg);
    if (senderRole === "client") {
      const art = db.getArtisanById(parseInt(artisanId, 10));
      if (art) {
        db.updateArtisan(art.id, { contactsCount: (art.contactsCount || 0) + 1 });
      }
      db.createNotification({
        id: `notif-${Date.now()}`,
        recipientId: `user-artisan-${artisanId}`,
        title: `Nouveau message de ${senderName || "un client"}`,
        message: text.length > 60 ? `${text.slice(0, 60)}...` : text,
        type: "message",
        date: (/* @__PURE__ */ new Date()).toISOString(),
        read: false,
        linkPage: "messages"
      });
    }
    res.status(201).json(newMsg);
  });
  app.get("/api/quotes", (req, res) => {
    const clientId = req.query.clientId;
    const artisanId = req.query.artisanId ? parseInt(req.query.artisanId, 10) : void 0;
    const quotes = db.getQuotes({ clientId, artisanId });
    res.json(quotes);
  });
  app.post("/api/quotes", (req, res) => {
    const { clientId, clientName, clientPhone, artisanId, artisanName, serviceTitle, description, estimatedPrice } = req.body;
    const quote = {
      id: `quote-${Date.now()}`,
      clientId: clientId || "user-client-1",
      clientName: clientName || "Client",
      clientPhone: clientPhone || "+225 00 00 00 00",
      artisanId: parseInt(artisanId, 10),
      artisanName: artisanName || "Artisan",
      serviceTitle: serviceTitle || "Demande de prestation personnalis\xE9e",
      description: description || "Pas de d\xE9tails fournis",
      status: "en_attente",
      estimatedPrice: estimatedPrice || "\xC0 \xE9valuer",
      date: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.createQuote(quote);
    db.createNotification({
      id: `notif-${Date.now()}`,
      recipientId: `user-artisan-${artisanId}`,
      title: `Nouvelle demande de devis`,
      message: `${clientName || "Un client"} demande un devis pour "${serviceTitle}".`,
      type: "quote",
      date: (/* @__PURE__ */ new Date()).toISOString(),
      read: false,
      linkPage: "account"
    });
    res.status(201).json(quote);
  });
  app.patch("/api/quotes/:id", (req, res) => {
    const { status } = req.body;
    const quote = db.updateQuoteStatus(req.params.id, status);
    if (!quote) {
      return res.status(404).json({ error: "Devis non trouv\xE9" });
    }
    db.createNotification({
      id: `notif-${Date.now()}`,
      recipientId: quote.clientId,
      title: `Mise \xE0 jour devis: ${quote.serviceTitle}`,
      message: `Votre artisan ${quote.artisanName} a marqu\xE9 le devis comme : ${status.toUpperCase()}.`,
      type: "quote",
      date: (/* @__PURE__ */ new Date()).toISOString(),
      read: false,
      linkPage: "account"
    });
    res.json(quote);
  });
  app.post("/api/subscriptions/checkout", (req, res) => {
    const { artisanId, paymentMethod = "Acc\xE8s Gratuit" } = req.body;
    if (!artisanId) {
      return res.status(400).json({ error: "Artisan ID requis" });
    }
    const artisan = db.getArtisanById(parseInt(artisanId, 10));
    if (!artisan) {
      return res.status(404).json({ error: "Artisan non trouv\xE9" });
    }
    const invoiceNumber = `FREE-${Date.now().toString().slice(-6)}`;
    const transaction = {
      id: `tx-${Date.now()}`,
      artisanId: artisan.id,
      artisanName: artisan.name,
      plan: "Pro",
      amount: 0,
      currency: "FCFA",
      method: paymentMethod || "Acc\xE8s Gratuit",
      status: "reussi",
      date: (/* @__PURE__ */ new Date()).toISOString(),
      invoiceNumber
    };
    db.createTransaction(transaction);
    db.updateArtisan(artisan.id, {
      plan: "Pro",
      verified: true
    });
    db.createNotification({
      id: `notif-${Date.now()}`,
      recipientId: `user-artisan-${artisan.id}`,
      title: `Compte Artisan activ\xE9 avec succ\xE8s (100% Gratuit) !`,
      message: `Inscrit et connect\xE9 est gratuit : c'est le d\xE9but ! Vous b\xE9n\xE9ficiez de la visibilit\xE9 compl\xE8te sans aucun frais.`,
      type: "system",
      date: (/* @__PURE__ */ new Date()).toISOString(),
      read: false,
      linkPage: "account"
    });
    res.json({
      success: true,
      transaction,
      artisan: db.getArtisanById(artisan.id),
      message: "Inscription et connexion 100% gratuites ! Aucun paiement requis."
    });
  });
  app.get("/api/transactions", (req, res) => {
    const headerRole = (req.headers["x-user-role"] || "").toLowerCase();
    const queryRole = (req.query.role || "").toLowerCase();
    const role = headerRole || queryRole;
    if (role !== "admin" && role !== "super_admin") {
      return res.status(403).json({
        error: "Acc\xE8s interdit. Seuls les administrateurs et super-administrateurs peuvent consulter les transactions r\xE9centes."
      });
    }
    res.json(db.getTransactions());
  });
  app.get("/api/notifications", (req, res) => {
    const userId = req.query.userId;
    res.json(db.getNotifications(userId));
  });
  app.post("/api/notifications/read", (req, res) => {
    const { id } = req.body;
    db.markNotificationRead(id);
    res.json({ success: true });
  });
  app.post("/api/notifications/read-all", (req, res) => {
    const { userId } = req.body;
    db.markAllNotificationsRead(userId);
    res.json({ success: true });
  });
  app.get("/api/admin/stats", (req, res) => {
    res.json(db.getAdminStats());
  });
  app.post("/api/admin/artisans/:id/verify", (req, res) => {
    const id = parseInt(req.params.id, 10);
    const artisan = db.getArtisanById(id);
    if (!artisan) {
      return res.status(404).json({ error: "Artisan non trouv\xE9" });
    }
    const newStatus = !artisan.verified;
    const updated = db.updateArtisan(id, { verified: newStatus });
    db.createNotification({
      id: `notif-${Date.now()}`,
      recipientId: `user-artisan-${id}`,
      title: newStatus ? "Votre profil est d\xE9sormais V\xE9rifi\xE9 !" : "Statut de v\xE9rification mis \xE0 jour",
      message: newStatus ? "F\xE9licitations, vos documents ont \xE9t\xE9 valid\xE9s par l\u2019administration Artisan Pro. Votre badge est actif." : "Votre statut de v\xE9rification a \xE9t\xE9 r\xE9initialis\xE9 par un administrateur.",
      type: "system",
      date: (/* @__PURE__ */ new Date()).toISOString(),
      read: false,
      linkPage: "account"
    });
    res.json(updated);
  });
  app.post("/api/admin/broadcast", (req, res) => {
    const { title, message } = req.body;
    if (!title || !message) {
      return res.status(400).json({ error: "Titre et message requis" });
    }
    const notif = db.createNotification({
      id: `notif-${Date.now()}`,
      recipientId: "all",
      title,
      message,
      type: "system",
      date: (/* @__PURE__ */ new Date()).toISOString(),
      read: false,
      linkPage: "home"
    });
    res.status(201).json(notif);
  });
  app.get("/api/subscriptions", (req, res) => {
    const { userId } = req.query;
    if (userId && typeof userId === "string") {
      res.json(db.getUserSubscriptions(userId));
    } else {
      res.json(db.getSubscriptions());
    }
  });
  app.post("/api/subscriptions", (req, res) => {
    const { user_id, plan, price, currency = "XOF", billing_period, status = "pending", start_date, end_date, payment_provider, transaction_id } = req.body;
    if (!user_id || !plan || price === void 0 || !billing_period) {
      return res.status(400).json({ error: "Champs requis manquants pour la souscription" });
    }
    const sub = db.createSubscription({
      id: `sub-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      user_id,
      plan,
      price: Number(price),
      currency: "XOF",
      billing_period,
      status,
      start_date: start_date || (/* @__PURE__ */ new Date()).toISOString(),
      end_date: end_date || new Date(Date.now() + (billing_period === "yearly" ? 365 : 30) * 24 * 60 * 60 * 1e3).toISOString(),
      payment_provider,
      transaction_id
    });
    res.status(201).json(sub);
  });
  app.patch("/api/subscriptions/:id", (req, res) => {
    const updated = db.updateSubscription(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ error: "Abonnement introuvable" });
    }
    res.json(updated);
  });
  app.get("/api/payments", (req, res) => {
    const { userId } = req.query;
    if (userId && typeof userId === "string") {
      res.json(db.getUserPayments(userId));
    } else {
      res.json(db.getPayments());
    }
  });
  app.post("/api/payments", (req, res) => {
    const { user_id, subscription_id, amount, currency = "XOF", payment_type, payment_method, provider, transaction_id, status = "completed" } = req.body;
    if (!user_id || amount === void 0 || !payment_type || !payment_method || !provider || !transaction_id) {
      return res.status(400).json({ error: "Champs requis manquants pour le paiement" });
    }
    const payment = db.createPayment({
      id: `pay-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      user_id,
      subscription_id,
      amount: Number(amount),
      currency,
      payment_type,
      payment_method,
      provider,
      transaction_id,
      status
    });
    res.status(201).json(payment);
  });
  function activateArtisanSubscriptionServerSide(transactionId) {
    const payments = db.getPayments();
    const payment = payments.find((p) => p.transaction_id === transactionId);
    const subscriptions = db.getSubscriptions();
    const subscription = subscriptions.find((s) => s.transaction_id === transactionId);
    if (payment) {
      db.updatePayment(payment.id, { status: "completed" });
    }
    if (subscription) {
      const durationDays = subscription.billing_period === "yearly" ? 365 : 30;
      const startDate = /* @__PURE__ */ new Date();
      const endDate = new Date(startDate.getTime() + durationDays * 24 * 60 * 60 * 1e3);
      db.updateSubscription(subscription.id, {
        status: "active",
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString()
      });
      const user = db.getUserById(subscription.user_id);
      if (user) {
        db.updateUser(user.id, {
          role: "artisan",
          subscription_status: "active",
          artisan_status: "active",
          subscription_plan: subscription.plan,
          subscription_end_date: endDate.toISOString()
        });
        const existingArtisans = db.getArtisans();
        const existingArtisan = existingArtisans.find(
          (a) => user.email && a.email?.toLowerCase() === user.email.toLowerCase() || user.artisanId && a.id === user.artisanId
        );
        const planLabel = subscription.plan === "premium" ? "Premium" : subscription.plan === "pro" ? "Pro" : "Free";
        if (existingArtisan) {
          db.updateArtisan(existingArtisan.id, {
            plan: planLabel,
            verified: true
          });
        } else {
          const newArtisan = db.createArtisan({
            name: user.name || "Artisan Qualifi\xE9",
            trade: user.trade || "Menuisier & Am\xE9nagement",
            city: user.city || "Abidjan",
            country: user.country || "C\xF4te d\u2019Ivoire",
            rating: 5,
            reviewsCount: 1,
            plan: planLabel,
            emoji: "\u{1F6E0}\uFE0F",
            services: [user.trade || "Prestations sur mesure"],
            description: user.bio || "Artisan professionnel certifi\xE9 ArtisanPro Afrique.",
            phone: user.phone || "+225 07 00 00 00",
            email: user.email || `artisan-${user.id}@artisanpro.africa`,
            lat: 5.345,
            lng: -4.024,
            verified: true,
            hourlyRate: "15 000 FCFA",
            experienceYears: 5,
            profileViews: 0,
            contactsCount: 0,
            joinedDate: (/* @__PURE__ */ new Date()).toISOString()
          });
          db.updateUser(user.id, { artisanId: newArtisan.id });
        }
        db.createNotification({
          id: `notif-${Date.now()}`,
          recipientId: user.id,
          title: "F\xE9licitations ! Votre compte ArtisanPro est actif \u{1F389}",
          message: `Votre abonnement ${subscription.plan.toUpperCase()} a \xE9t\xE9 valid\xE9 avec succ\xE8s par CinetPay. Bienvenue dans votre espace ArtisanPro !`,
          type: "payment",
          date: (/* @__PURE__ */ new Date()).toISOString(),
          read: false,
          linkPage: "account"
        });
      }
    }
  }
  app.post("/api/cinetpay/initiate", async (req, res) => {
    try {
      const {
        userId,
        plan,
        billingPeriod,
        countryCode = "CI",
        countryName = "C\xF4te d\u2019Ivoire",
        paymentMethod = "Orange Money",
        customerName = "Artisan Client",
        customerPhone = "+225 0700000000",
        customerEmail = "client@artisanpro.africa"
      } = req.body;
      if (!userId || !plan || !billingPeriod) {
        return res.status(400).json({ error: "Champs requis manquants: userId, plan, billingPeriod" });
      }
      const PRICING = {
        essential: { monthly: 300, yearly: 4e3 },
        pro: { monthly: 700, yearly: 8e3 },
        premium: { monthly: 1e3, yearly: 11e3 }
      };
      const planPricing = PRICING[plan];
      if (!planPricing) {
        return res.status(400).json({ error: "Plan d\u2019abonnement invalide" });
      }
      const amount = billingPeriod === "yearly" ? planPricing.yearly : planPricing.monthly;
      const transactionId = `CP_${Date.now()}_${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
      const sub = db.createSubscription({
        id: `sub-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        user_id: String(userId),
        plan,
        price: amount,
        currency: "XOF",
        billing_period: billingPeriod,
        status: "pending",
        start_date: (/* @__PURE__ */ new Date()).toISOString(),
        end_date: new Date(Date.now() + (billingPeriod === "yearly" ? 365 : 30) * 24 * 3600 * 1e3).toISOString(),
        payment_provider: "CinetPay",
        transaction_id: transactionId
      });
      db.createPayment({
        id: `pay-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        user_id: String(userId),
        subscription_id: sub.id,
        amount,
        currency: "XOF",
        payment_type: "subscription",
        payment_method: paymentMethod,
        provider: "CinetPay",
        transaction_id: transactionId,
        status: "pending"
      });
      const apiKey = process.env.CINETPAY_API_KEY;
      const siteId = process.env.CINETPAY_SITE_ID;
      if (apiKey && siteId) {
        try {
          const protocol = req.headers["x-forwarded-proto"] || req.protocol || "https";
          const host = req.get("host") || "localhost:3000";
          const origin = `${protocol}://${host}`;
          const cinetPayPayload = {
            apikey: apiKey,
            site_id: siteId,
            transaction_id: transactionId,
            amount,
            currency: "XOF",
            description: `Abonnement ArtisanPro ${plan.toUpperCase()} - ${billingPeriod === "yearly" ? "Annuel" : "Mensuel"}`,
            notify_url: `${origin}/api/cinetpay/notify`,
            return_url: `${origin}/?page=abonnements&cinetpay_tx=${transactionId}`,
            channels: "ALL",
            customer_id: String(userId),
            customer_name: (customerName || "Artisan").split(" ")[0] || "Artisan",
            customer_surname: (customerName || "Artisan").split(" ").slice(1).join(" ") || "Afrique",
            customer_phone_number: (customerPhone || "+22507000000").replace(/\s+/g, ""),
            customer_email: customerEmail || "client@artisanpro.africa",
            customer_address: "Afrique",
            customer_city: "Abidjan",
            customer_country: (countryCode || "CI").toUpperCase(),
            customer_state: (countryCode || "CI").toUpperCase(),
            customer_zip_code: "00225"
          };
          const cpResponse = await fetch("https://api-checkout.cinetpay.com/v2/payment", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(cinetPayPayload)
          });
          const cpData = await cpResponse.json();
          if (cpData.code === "201" && cpData.data?.payment_url) {
            return res.json({
              success: true,
              transaction_id: transactionId,
              payment_url: cpData.data.payment_url,
              payment_token: cpData.data.payment_token,
              amount,
              plan,
              billingPeriod,
              countryCode,
              paymentMethod
            });
          } else {
            return res.status(400).json({
              success: false,
              error: cpData.message || cpData.description || "Erreur CinetPay",
              transaction_id: transactionId
            });
          }
        } catch (cpErr) {
          console.error("CinetPay API request failed:", cpErr);
          return res.status(502).json({
            success: false,
            error: "Impossible de joindre la passerelle CinetPay: " + (cpErr.message || ""),
            transaction_id: transactionId
          });
        }
      }
      return res.json({
        success: true,
        transaction_id: transactionId,
        amount,
        plan,
        billingPeriod,
        countryCode,
        paymentMethod,
        requires_credentials: true,
        message: "Initialisation r\xE9ussie. En attente de validation CinetPay via webhook.",
        notify_url: "/api/cinetpay/notify"
      });
    } catch (err) {
      console.error("Initiate payment error:", err);
      res.status(500).json({ error: err.message || "Erreur serveur" });
    }
  });
  app.post("/api/cinetpay/notify", async (req, res) => {
    try {
      const txId = req.body?.cpm_trans_id || req.body?.transaction_id || req.query?.cpm_trans_id;
      if (!txId) {
        return res.status(400).json({ error: "transaction_id requis" });
      }
      const apiKey = process.env.CINETPAY_API_KEY;
      const siteId = process.env.CINETPAY_SITE_ID;
      let isConfirmed = false;
      if (apiKey && siteId) {
        try {
          const checkRes = await fetch("https://api-checkout.cinetpay.com/v2/payment/check", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              apikey: apiKey,
              site_id: siteId,
              transaction_id: txId
            })
          });
          const checkData = await checkRes.json();
          if (checkData?.code === "00" && checkData?.data?.status === "ACCEPTED") {
            isConfirmed = true;
          }
        } catch (checkErr) {
          console.error("CinetPay check error:", checkErr);
        }
      } else {
        isConfirmed = true;
      }
      if (isConfirmed) {
        activateArtisanSubscriptionServerSide(txId);
        return res.status(200).json({
          status: "ok",
          code: "00",
          message: "Paiement confirm\xE9 avec succ\xE8s via webhook CinetPay"
        });
      } else {
        return res.status(400).json({
          status: "failed",
          message: "Paiement non confirm\xE9 par CinetPay"
        });
      }
    } catch (err) {
      console.error("CinetPay notify webhook error:", err);
      res.status(500).json({ error: err.message });
    }
  });
  app.get("/api/cinetpay/check/:transactionId", async (req, res) => {
    const txId = req.params.transactionId;
    const payment = db.getPayments().find((p) => p.transaction_id === txId);
    const subscription = db.getSubscriptions().find((s) => s.transaction_id === txId);
    if (!payment || !subscription) {
      return res.status(404).json({ error: "Transaction introuvable" });
    }
    if (subscription.status === "active" && payment.status === "completed") {
      const user = db.getUserById(subscription.user_id);
      return res.json({
        status: "completed",
        subscription_status: "active",
        role: user?.role || "artisan",
        artisan_status: user?.artisan_status || "active",
        message: "Paiement d\xE9j\xE0 confirm\xE9"
      });
    }
    const apiKey = process.env.CINETPAY_API_KEY;
    const siteId = process.env.CINETPAY_SITE_ID;
    if (apiKey && siteId) {
      try {
        const checkRes = await fetch("https://api-checkout.cinetpay.com/v2/payment/check", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            apikey: apiKey,
            site_id: siteId,
            transaction_id: txId
          })
        });
        const checkData = await checkRes.json();
        if (checkData?.code === "00" && checkData?.data?.status === "ACCEPTED") {
          activateArtisanSubscriptionServerSide(txId);
          return res.json({
            status: "completed",
            subscription_status: "active",
            role: "artisan",
            artisan_status: "active",
            message: "Paiement confirm\xE9 avec succ\xE8s par CinetPay"
          });
        }
      } catch (e) {
        console.warn("CinetPay polling error:", e);
      }
    }
    return res.json({
      status: payment.status,
      subscription_status: subscription.status
    });
  });
  app.post("/api/cinetpay/simulate-webhook", (req, res) => {
    const { transaction_id } = req.body;
    if (!transaction_id) {
      return res.status(400).json({ error: "transaction_id requis" });
    }
    activateArtisanSubscriptionServerSide(transaction_id);
    const payment = db.getPayments().find((p) => p.transaction_id === transaction_id);
    const subscription = db.getSubscriptions().find((s) => s.transaction_id === transaction_id);
    const user = subscription ? db.getUserById(subscription.user_id) : null;
    res.json({
      success: true,
      message: "Simulation webhook CinetPay ex\xE9cut\xE9e avec succ\xE8s",
      payment,
      subscription,
      user: user ? {
        id: user.id,
        role: user.role,
        subscription_status: user.subscription_status,
        artisan_status: user.artisan_status,
        subscription_plan: user.subscription_plan,
        subscription_end_date: user.subscription_end_date
      } : null
    });
  });
  app.post("/api/admin/simulate-expire", (req, res) => {
    const { userId } = req.body;
    if (!userId) {
      return res.status(400).json({ error: "userId requis" });
    }
    const user = db.getUserById(userId);
    if (!user) {
      return res.status(404).json({ error: "Utilisateur non trouv\xE9" });
    }
    const yesterday = new Date(Date.now() - 24 * 3600 * 1e3).toISOString();
    db.updateUser(user.id, {
      subscription_status: "expired",
      artisan_status: "expired",
      subscription_end_date: yesterday
    });
    const userSubs = db.getUserSubscriptions(userId);
    for (const s of userSubs) {
      if (s.status === "active") {
        db.updateSubscription(s.id, { status: "expired", end_date: yesterday });
      }
    }
    res.json({
      success: true,
      message: "Abonnement marqu\xE9 comme expir\xE9 c\xF4t\xE9 serveur",
      user: {
        id: user.id,
        role: user.role,
        subscription_status: "expired",
        artisan_status: "expired",
        subscription_plan: user.subscription_plan,
        subscription_end_date: yesterday
      }
    });
  });
  app.get("/api/user/subscription-status/:userId", (req, res) => {
    const userId = req.params.userId;
    const user = db.getUserById(userId);
    if (!user) {
      return res.status(404).json({ error: "Utilisateur non trouv\xE9" });
    }
    let isExpired = false;
    if (user.subscription_end_date && new Date(user.subscription_end_date).getTime() < Date.now()) {
      isExpired = true;
      db.updateUser(user.id, {
        subscription_status: "expired",
        artisan_status: "expired"
      });
      user.subscription_status = "expired";
      user.artisan_status = "expired";
      const userSubs = db.getUserSubscriptions(userId);
      for (const s of userSubs) {
        if (s.status === "active") {
          db.updateSubscription(s.id, { status: "expired" });
        }
      }
    }
    const subscriptions = db.getUserSubscriptions(userId);
    const payments = db.getUserPayments(userId);
    res.json({
      userId: user.id,
      role: user.role,
      subscription_status: user.subscription_status || "none",
      artisan_status: user.artisan_status || "inactive",
      subscription_plan: user.subscription_plan,
      subscription_end_date: user.subscription_end_date,
      isExpired,
      canAccessProFeatures: user.subscription_status === "active",
      subscriptions,
      payments
    });
  });
  app.get("/api/admin/subscriptions-summary", (req, res) => {
    const subscriptions = db.getSubscriptions();
    const payments = db.getPayments();
    const users = db.getUsers();
    const now = Date.now();
    let totalActive = 0;
    let essentialActive = 0;
    let proActive = 0;
    let premiumActive = 0;
    let expiredCount = 0;
    for (const s of subscriptions) {
      const isPast = s.end_date && new Date(s.end_date).getTime() < now;
      if (s.status === "expired" || isPast) {
        expiredCount++;
      } else if (s.status === "active") {
        totalActive++;
        if (s.plan === "essential") essentialActive++;
        else if (s.plan === "pro") proActive++;
        else if (s.plan === "premium") premiumActive++;
      }
    }
    let successfulPayments = 0;
    let failedPayments = 0;
    let totalRevenueFCFA = 0;
    const byPaymentMethod = {};
    const byCountry = {};
    for (const p of payments) {
      const isSuccess = p.status === "completed" || p.status === "reussi";
      if (isSuccess) {
        successfulPayments++;
        totalRevenueFCFA += Number(p.amount) || 0;
        const method = p.payment_method || "Mobile Money";
        if (!byPaymentMethod[method]) byPaymentMethod[method] = { count: 0, revenue: 0 };
        byPaymentMethod[method].count++;
        byPaymentMethod[method].revenue += Number(p.amount) || 0;
        const user = users.find((u) => u.id === p.user_id || String(u.id) === String(p.user_id));
        const country = user?.country || "C\xF4te d\u2019Ivoire";
        if (!byCountry[country]) byCountry[country] = { count: 0, revenue: 0 };
        byCountry[country].count++;
        byCountry[country].revenue += Number(p.amount) || 0;
      } else if (p.status === "failed" || p.status === "echoue") {
        failedPayments++;
      }
    }
    res.json({
      totalActive,
      essentialActive,
      proActive,
      premiumActive,
      expiredCount,
      successfulPayments,
      failedPayments,
      totalRevenueFCFA,
      byCountry,
      byPaymentMethod,
      subscriptions,
      payments
    });
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path2.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path2.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Artisan Pro server running on http://0.0.0.0:${PORT}`);
  });
}
startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
//# sourceMappingURL=server.cjs.map
